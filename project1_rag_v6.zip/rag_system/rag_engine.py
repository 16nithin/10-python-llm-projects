"""
rag_engine.py
-------------
The main RAG (Retrieval-Augmented Generation) engine.
This ties everything together:

  1. User asks a question
  2. HybridSearch finds relevant document chunks
  3. Reranker scores and filters them
  4. Gemini generates an answer using those chunks
  5. The answer includes citations so users can verify it

RAG = Retrieval + Generation
     (find relevant info) + (generate answer using that info)

NOTE: Uses Google Gemini API (FREE) via OpenAI-compatible endpoint.
Get your free key at: aistudio.google.com
"""

import os
import json
from typing import List, Dict, Any, Optional, Tuple
from openai import OpenAI
from dotenv import load_dotenv

from document_processor import process_documents
from vector_store import VectorStore
from hybrid_search import HybridSearch
from reranker import LLMReranker


# Load environment variables from .env file
load_dotenv()


class RAGEngine:
    """
    The complete RAG pipeline — from documents to answers with citations.
    """

    def __init__(
        self,
        openai_api_key: Optional[str] = None,
        model: str = "gemini-1.5-flash",        # Answer generation model (FREE)
        rerank_model: str = "gemini-1.5-flash", # Reranking model (FREE)
        collection_name: str = "rag_docs",
        persist_dir: str = "./chroma_db"
    ):
        """
        Initialize all components of the RAG system.

        Args:
            openai_api_key: Your Google Gemini API key (or set GEMINI_API_KEY env var)
            model: Gemini model for generating answers
            rerank_model: Gemini model for reranking
            collection_name: ChromaDB collection name
            persist_dir: Where to store the vector database
        """
        # Set up client pointing to Gemini's OpenAI-compatible endpoint
        api_key = openai_api_key or os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("Gemini API key required! Set GEMINI_API_KEY in .env file.\nGet a free key at: aistudio.google.com")

        # Gemini supports the OpenAI API format — just change the base_url!
        self.client = OpenAI(
            api_key=api_key,
            base_url="https://generativelanguage.googleapis.com/v1beta/openai/"
        )
        self.model = model

        # Initialize all components
        print("\n🚀 Initializing RAG Engine...\n")
        self.vector_store = VectorStore(api_key=api_key, collection_name=collection_name, persist_dir=persist_dir)
        self.hybrid_search = HybridSearch(self.vector_store)
        self.reranker = LLMReranker(self.client, model=rerank_model)

        # Build BM25 index if we have existing documents
        if self.vector_store.count() > 0:
            self.hybrid_search.build_bm25_index()

        # Conversation history for multi-turn chat
        self.conversation_history: List[Dict[str, str]] = []

        print("\n✅ RAG Engine ready!\n")

    def add_documents(self, file_paths: List[str], chunk_size: int = 500) -> None:
        """
        Add documents to the knowledge base.

        Args:
            file_paths: List of paths to PDF, DOCX, or TXT files
            chunk_size: Size of each text chunk in characters
        """
        print(f"\n📚 Adding {len(file_paths)} document(s) to knowledge base...\n")

        # Step 1: Load and chunk documents
        chunks = process_documents(file_paths, chunk_size=chunk_size)

        if not chunks:
            print("❌ No chunks created. Check your documents.")
            return

        # Step 2: Add to vector store
        self.vector_store.add_documents(chunks)

        # Step 3: Rebuild BM25 index with new documents
        self.hybrid_search.build_bm25_index()

        print(f"\n✅ Knowledge base updated! Total chunks: {self.vector_store.count()}")

    def retrieve(self, query: str, n_candidates: int = 10, n_final: int = 4) -> List[Dict[str, Any]]:
        """
        Retrieve the most relevant document chunks for a query.

        Pipeline:
          Query → Hybrid Search (10 candidates) → Reranker → Top 4 chunks

        Args:
            query: The user's question
            n_candidates: How many candidates to retrieve before reranking
            n_final: How many chunks to use for generation

        Returns:
            List of the most relevant document chunks
        """
        # Step 1: Hybrid search (semantic + keyword)
        candidates = self.hybrid_search.search(query, n_results=n_candidates)

        if not candidates:
            return []

        # Step 2: Rerank using LLM
        final_chunks = self.reranker.rerank(query, candidates, top_k=n_final)

        return final_chunks

    def generate(self, query: str, context_chunks: List[Dict[str, Any]]) -> Tuple[str, List[str]]:
        """
        Generate an answer using the query and retrieved context chunks.

        Args:
            query: The user's question
            context_chunks: Relevant document chunks from retrieve()

        Returns:
            Tuple of (answer_text, list_of_citations)
        """
        if not context_chunks:
            return (
                "I couldn't find relevant information in the knowledge base to answer this question. "
                "Please make sure you've uploaded relevant documents, or try rephrasing your question.",
                []
            )

        # Format context for the prompt
        context_parts = []
        citations = []

        for i, chunk in enumerate(context_chunks, 1):
            context_parts.append(f"[Source {i}: {chunk['source']}]\n{chunk['text']}")
            if chunk['source'] not in citations:
                citations.append(chunk['source'])

        context_text = "\n\n---\n\n".join(context_parts)

        # Build the system prompt
        system_prompt = """You are a helpful knowledge assistant. Answer questions based ONLY on the provided context.

Rules:
1. Only use information from the provided context
2. Cite your sources using [Source N] notation inline
3. If the context doesn't contain enough information, say so clearly
4. Be concise but complete
5. If asked about something not in the context, say "This information is not in the provided documents"

Format your response clearly with the answer followed by citations."""

        # Build the user prompt with context
        user_prompt = f"""Context from knowledge base:

{context_text}

---

Question: {query}

Please answer based on the context above, citing your sources."""

        # Add to conversation history (for multi-turn chat)
        self.conversation_history.append({"role": "user", "content": user_prompt})

        # Keep conversation history manageable (last 6 turns)
        recent_history = self.conversation_history[-6:]

        # Generate answer
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                *recent_history
            ],
            temperature=0.1,  # Low temperature for factual accuracy
            max_tokens=1000
        )

        answer = response.choices[0].message.content

        # Add assistant response to history
        self.conversation_history.append({"role": "assistant", "content": answer})

        return answer, citations

    def evaluate_answer(self, query: str, answer: str, context_chunks: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Evaluate the quality of the generated answer.
        Checks for faithfulness, relevance, and completeness.

        This is "RAG evaluation" — making the system grade its own outputs.
        """
        context_text = "\n\n".join([chunk["text"] for chunk in context_chunks])

        eval_prompt = f"""You are an expert RAG evaluator. Evaluate this answer on 3 dimensions.

Question: {query}

Context provided:
{context_text[:2000]}

Generated Answer:
{answer}

Evaluate on these dimensions (score each 1-5):

1. FAITHFULNESS (1-5): Does the answer only use information from the context? No hallucinations?
2. RELEVANCE (1-5): Does the answer actually address the question asked?
3. COMPLETENESS (1-5): Does the answer cover all important aspects from the context?

Respond with ONLY a JSON object:
{{
    "faithfulness": <1-5>,
    "relevance": <1-5>,
    "completeness": <1-5>,
    "overall": <1-5>,
    "feedback": "<one sentence of overall feedback>"
}}"""

        try:
            response = self.client.chat.completions.create(
                model="gemini-1.5-flash",
                messages=[{"role": "user", "content": eval_prompt}],
                temperature=0,
                max_tokens=200
            )

            eval_result = json.loads(response.choices[0].message.content.strip())
            return eval_result

        except Exception as e:
            return {
                "faithfulness": 0,
                "relevance": 0,
                "completeness": 0,
                "overall": 0,
                "feedback": f"Evaluation failed: {e}"
            }

    def ask(
        self,
        query: str,
        n_candidates: int = 10,
        n_final: int = 4,
        evaluate: bool = False
    ) -> Dict[str, Any]:
        """
        Complete RAG pipeline: query → retrieve → generate → (evaluate).

        This is the main function to call for answering questions.

        Args:
            query: The user's question
            n_candidates: Candidates for retrieval before reranking
            n_final: Final chunks to use for generation
            evaluate: Whether to run self-evaluation (slower, uses extra API calls)

        Returns:
            Dict with 'answer', 'citations', 'context', and optional 'evaluation'
        """
        print(f"\n❓ Query: {query}\n")

        # Step 1: Retrieve relevant chunks
        print("🔍 Searching knowledge base...")
        context_chunks = self.retrieve(query, n_candidates=n_candidates, n_final=n_final)

        # Step 2: Generate answer
        print("💭 Generating answer...")
        answer, citations = self.generate(query, context_chunks)

        result = {
            "query": query,
            "answer": answer,
            "citations": citations,
            "context_chunks": context_chunks,
            "num_sources_found": len(context_chunks)
        }

        # Step 3: Optional evaluation
        if evaluate and context_chunks:
            print("📊 Evaluating answer quality...")
            evaluation = self.evaluate_answer(query, answer, context_chunks)
            result["evaluation"] = evaluation

        return result

    def clear_history(self) -> None:
        """Clear conversation history (start fresh)."""
        self.conversation_history = []
        print("🔄 Conversation history cleared.")

    def clear_history(self) -> None:
        """Clear conversation history (start fresh)."""
        self.conversation_history = []
        print("🔄 Conversation history cleared.")
