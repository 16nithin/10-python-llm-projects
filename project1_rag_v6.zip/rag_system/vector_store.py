"""
vector_store.py
---------------
FAISS vector store using Gemini embeddings via direct REST API calls.

Uses Python's `requests` library (already installed) to call:
  https://generativelanguage.googleapis.com/v1beta/models/text-embedding-004:batchEmbedContents

No google-generativeai package needed. No grpc. No HuggingFace.
"""

import os
import json
import numpy as np
import faiss
import requests
from typing import List, Dict, Any


GEMINI_EMBED_URL = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    "text-embedding-004:batchEmbedContents"
)


class VectorStore:
    """
    FAISS vector store with Gemini text-embedding-004 embeddings.
    Persists to disk so documents survive restarts.
    """

    EMBEDDING_DIM = 768  # text-embedding-004 outputs 768-dimensional vectors

    def __init__(
        self,
        api_key: str,
        collection_name: str = "rag_documents",
        persist_dir: str = "./faiss_db"
    ):
        self.api_key = api_key

        # Disk paths
        self.persist_dir = persist_dir
        self.collection_name = collection_name
        os.makedirs(persist_dir, exist_ok=True)
        self.index_path = os.path.join(persist_dir, f"{collection_name}.bin")
        self.metadata_path = os.path.join(persist_dir, f"{collection_name}_metadata.json")

        self._load_or_create_index()
        print(f"✅ Vector store ready. Documents indexed: {len(self.metadata)}")

    def _load_or_create_index(self):
        if os.path.exists(self.index_path) and os.path.exists(self.metadata_path):
            print("📂 Loading existing index from disk...")
            self.index = faiss.read_index(self.index_path)
            with open(self.metadata_path, "r", encoding="utf-8") as f:
                self.metadata = json.load(f)
        else:
            print("🆕 Creating new FAISS index...")
            self.index = faiss.IndexFlatIP(self.EMBEDDING_DIM)
            self.metadata = []

    def _save_to_disk(self):
        faiss.write_index(self.index, self.index_path)
        with open(self.metadata_path, "w", encoding="utf-8") as f:
            json.dump(self.metadata, f, ensure_ascii=False, indent=2)

    def _embed(self, texts: List[str]) -> np.ndarray:
        """
        Call Gemini batchEmbedContents REST endpoint directly.
        Processes up to 100 texts per batch (API limit).
        """
        all_embeddings = []
        batch_size = 100

        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]

            # Build the batch request body
            payload = {
                "requests": [
                    {
                        "model": "models/text-embedding-004",
                        "content": {
                            "parts": [{"text": text}]
                        }
                    }
                    for text in batch
                ]
            }

            response = requests.post(
                GEMINI_EMBED_URL,
                params={"key": self.api_key},
                headers={"Content-Type": "application/json"},
                json=payload,
                timeout=60
            )

            if response.status_code != 200:
                raise ValueError(
                    f"Gemini embedding API error {response.status_code}: {response.text}"
                )

            data = response.json()
            # Each item in "embeddings" has a "values" list
            for item in data["embeddings"]:
                all_embeddings.append(item["values"])

        # Normalize for cosine similarity with FAISS IndexFlatIP
        arr = np.array(all_embeddings, dtype=np.float32)
        norms = np.linalg.norm(arr, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1, norms)
        return arr / norms

    def add_documents(self, chunks: List[Dict[str, Any]]) -> None:
        if not chunks:
            print("⚠️  No chunks to add.")
            return

        existing_ids = {m.get("chunk_id") for m in self.metadata}
        new_chunks = [c for c in chunks if c.get("chunk_id") not in existing_ids]

        if not new_chunks:
            print("ℹ️  All chunks already indexed.")
            return

        print(f"🔄 Embedding {len(new_chunks)} chunks with Gemini...")

        texts = [chunk["text"] for chunk in new_chunks]
        embeddings = self._embed(texts)

        self.index.add(embeddings)

        for chunk in new_chunks:
            self.metadata.append({
                "text": chunk["text"],
                "source": chunk["source"],
                "chunk_id": chunk.get("chunk_id", ""),
                "start_char": chunk.get("start_char", 0),
                "end_char": chunk.get("end_char", 0)
            })

        self._save_to_disk()
        print(f"✅ Added {len(new_chunks)} chunks. Total: {len(self.metadata)}")

    def semantic_search(self, query: str, n_results: int = 10) -> List[Dict[str, Any]]:
        if not self.metadata:
            return []

        query_embedding = self._embed([query])
        n = min(n_results, len(self.metadata))
        scores, indices = self.index.search(query_embedding, n)

        results = []
        for rank, (score, idx) in enumerate(zip(scores[0], indices[0])):
            if idx == -1:
                continue
            meta = self.metadata[idx]
            results.append({
                "text": meta["text"],
                "source": meta["source"],
                "score": float(score),
                "rank": rank + 1,
                "search_type": "semantic"
            })

        return results

    def get_all_documents(self) -> List[Dict[str, Any]]:
        return [{"text": m["text"], "source": m["source"]} for m in self.metadata]

    def count(self) -> int:
        return len(self.metadata)

    def clear(self) -> None:
        self.index = faiss.IndexFlatIP(self.EMBEDDING_DIM)
        self.metadata = []
        self._save_to_disk()
        print("🗑️  Vector store cleared.")
