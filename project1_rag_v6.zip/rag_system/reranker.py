"""
reranker.py
-----------
After getting search results, we rerank them using the LLM itself.

Why? Because our initial search returns "possibly relevant" chunks.
The reranker asks GPT: "On a scale of 0-10, how relevant is this chunk
to the question?" — giving us much more precise rankings.

This is a 2-stage approach:
  Stage 1: Fast retrieval (hybrid search) — gets 10 candidates
  Stage 2: Precise reranking (LLM) — picks the best 3-5 from those 10
"""

import json
from typing import List, Dict, Any
from openai import OpenAI


class LLMReranker:
    """
    Uses an LLM to score and rerank retrieved document chunks.
    More accurate than embedding similarity alone.
    """

    def __init__(self, client: OpenAI, model: str = "gemini-1.5-flash"):
        """
        Args:
            client: OpenAI client instance
            model: Model to use for reranking (gpt-4o-mini is cheap and fast)
        """
        self.client = client
        self.model = model

    def score_document(self, query: str, document: str) -> float:
        """
        Ask the LLM to score how relevant a document is to the query.
        Returns a score from 0 to 10.
        """
        prompt = f"""You are a relevance scoring expert. Score how relevant the following document chunk is to answering the given query.

Query: {query}

Document chunk:
\"\"\"
{document[:1000]}
\"\"\"

Score from 0 to 10 where:
- 0: Completely irrelevant
- 5: Somewhat relevant, partial information
- 10: Highly relevant, directly answers the query

Respond with ONLY a JSON object in this format:
{{"score": <number>, "reason": "<one sentence explanation>"}}"""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0,  # We want consistent scores, not creative ones
                max_tokens=100
            )

            # Parse the JSON response
            result = json.loads(response.choices[0].message.content.strip())
            return float(result.get("score", 0)), result.get("reason", "")

        except Exception as e:
            print(f"⚠️  Reranking error: {e}")
            return 5.0, "Could not score"  # Default middle score on error

    def rerank(
        self,
        query: str,
        documents: List[Dict[str, Any]],
        top_k: int = 4
    ) -> List[Dict[str, Any]]:
        """
        Rerank a list of retrieved documents by LLM relevance scores.

        Args:
            query: The user's question
            documents: List of document chunks from hybrid search
            top_k: How many top documents to return after reranking

        Returns:
            Reranked list with LLM scores added
        """
        if not documents:
            return []

        print(f"🔄 Reranking {len(documents)} candidates...")

        # Score each document
        scored_docs = []
        for doc in documents:
            score, reason = self.score_document(query, doc["text"])
            doc_with_score = {
                **doc,  # Keep all existing fields
                "llm_relevance_score": score,
                "relevance_reason": reason
            }
            scored_docs.append(doc_with_score)

        # Sort by LLM relevance score (highest first)
        scored_docs.sort(key=lambda x: x["llm_relevance_score"], reverse=True)

        # Only keep docs with score > 3 (filter out irrelevant ones)
        filtered = [doc for doc in scored_docs if doc["llm_relevance_score"] > 3]

        print(f"✅ Reranking complete. Kept {min(top_k, len(filtered))} most relevant chunks.")

        return filtered[:top_k]
